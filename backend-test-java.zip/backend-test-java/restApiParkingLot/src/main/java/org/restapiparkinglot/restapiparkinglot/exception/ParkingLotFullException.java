package org.restapiparkinglot.restapiparkinglot.exception;

public class ParkingLotFullException {
    public class ParkingLotFullException extends RuntimeException{
        super(warning);
        
    }
}
