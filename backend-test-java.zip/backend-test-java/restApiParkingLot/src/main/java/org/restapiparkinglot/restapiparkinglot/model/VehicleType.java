package org.restapiparkinglot.restapiparkinglot.model;

public enum VehicleType {
    CAR,
    MOTORCYCLE
}
