package org.restapiparkinglot.restapiparkinglot.controller;

import org.restapiparkinglot.restapiparkinglot.services.ParkingService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.service.annotation.GetExchange;

@RestController
@RequestMapping (path = "/parkingservice" )
public class ParkingServiceController {
    @Autowired
    private ParkingService parkingService;

    @GetMapping
}
