package org.restapiparkinglot.restapiparkinglot.controller;

import org.restapiparkinglot.restapiparkinglot.dtos.VehicleDTO;
import org.restapiparkinglot.restapiparkinglot.model.Vehicle;
import org.restapiparkinglot.restapiparkinglot.services.VehicleService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(path = "/vehicle")
public class VehicleController {
    @Autowired
    private VehicleService vehicleService;

    @GetMapping
    public ResponseEntity<List<Vehicle>> findAll(){
        return ResponseEntity.status(HttpStatus.OK).body(vehicleService.findAll());
    }

    @GetMapping (value = "/{id}")
    public ResponseEntity<Object> findVehicleById(@PathVariable(value = "id"), int id) throws NotFoundException{
        return ResponseEntity.status(HttpStatus.OK).body(vehicleService.findById(id));
    }

    @GetMapping (value = "/{licensePlate}")
    public ResponseEntity<Object> findVehicleByLicensePlate(@PathVariable(value = "licensePlate"), String licensePlate) throws NotFoundException{
        return ResponseEntity.status(HttpStatus.OK).body(vehicleService.findByLicensePlate(licensePlate));
    }

    @PostMapping
    public ResponseEntity<Object> createVehicle(@RequestBody @Valid VehicleDTO vehicleDTO) {
        return ResponseEntity.status(HttpStatus.CREATED).body(vehicleDTO.create(vehicleDTO));
    }

    @PutMapping (value = "/{id}")
    public ResponseEntity<Object> updateVehicle(@RequestBody @Valid VehicleDTO vehicleDTO, @PathVariable(value = "id"), int id) throws NotFoundException{
        Vehicle vehicle = vehicleService.findById(id);
        
        BeanUtils.copyProperties(vehicleDTO, vehicle);
        return ResponseEntity.status(HttpStatus.OK).body(vehicleService.update(vehicle, id));
    }

    @DeleteMapping (value = "/{id}")
    public ResponseEntity<String> deleteVehicle(@PathVariable(value = "id") int id) throws NotFoundException{
        return ResponseEntity.status(HttpStatus.OK).body(vehicleService.delete(id));

    }

}
